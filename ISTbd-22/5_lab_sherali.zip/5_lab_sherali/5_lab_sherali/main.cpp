#include <fstream>
#include <iostream>
using namespace std;

void merge(int* a, int l, int m, int r)
{
    int i, j, k;
    int leftsize = m - l + 1, rigthsize = r - m;
    int* left_array = new int[leftsize];
    int* right_array = new int[rigthsize];
    for (i = 0; i < leftsize; ++i)
        left_array[i] = a[l + i];
    for (j = 0; j < rigthsize; ++j)
        right_array[j] = a[m + 1 + j];
    i = 0, j = 0, k = l;
    while (i < leftsize && j < rigthsize) {
        if (left_array[i] <= right_array[j])
            a[k++] = left_array[i++];
        else
            a[k++] = right_array[j++];
    }
    while (i < leftsize)
        a[k++] = left_array[i++];
    while (j < rigthsize)
        a[k++] = right_array[j++];
}


void mergesort(int* a, int l, int r)
{
    if (l >= r)
        return;
    int m = (r + l) / 2;
    mergesort(a, l, m);
    mergesort(a, m + 1, r);
    merge(a, l, m, r);
}

void print(int* a, int len) {
    for (int i = 0; i < len; i++)
        cout << a[i] << "  ";
    cout << endl << endl;
}

int main()
{
    setlocale(LC_ALL, "Russian");
    std::ifstream fin("input.txt");
    int count;
    fin >> count;
    cout << "���������� ���������: " << count << '\n';
    int* array = new int[count];
    for (int i = 0; i < count; ++i)
        fin >> array[i];
    cout << "�������������� ������: " << '\n';
    print(array, count);
    mergesort(array, 0, count - 1);
    cout << "��������������� ������: " << '\n';
    print(array, count);
    delete[] array;
    return 0;
}